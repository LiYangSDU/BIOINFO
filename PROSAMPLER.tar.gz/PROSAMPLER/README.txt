=========================================================================

			Obtaining ProSampler

=========================================================================

The easiest way to obtain and use ProSample is log in the website: 
http:pcrms.uncc.edu.
If you need a local version of ProSampler, please download and compile
this program.

=========================================================================

			Compiling the ProSampler

=========================================================================

To compile the ProSampler program, you need one command line:

	g++ -o ProSampler ProSampler.cc

=========================================================================

			Usage of ProSampler

=========================================================================

Before running ProSampler, you need put ProSampler in the directory 
containing your data.

Command line:

	./ProSampler <options>

Options:

-i:	The input ChIP-seq data in FASTA format. What to be emphazised is
	that this admits no empty line within the file, and one sequence 
	should be in one single line rather than multiple lines.
-b:	The input background data in FASTA format. The format requirement
	for this file is the same with that of "-i".
-o:	The prefix for output files. This program generates three output 
	files, i.e. ".meme" file, ".site" file and ".spic" file. The ".
	meme" file contains the identified motifs in MEME format. The ".
	site" file contains the sites for all identified motifs. The ".
	spic" file contains the position frequency matrices (PFM) and 
	the position scoring weight matrices (PSWM) for all identified 
	motifs, ready to be input to SPIC program so as to calculate the
	motif similarity.
-d:	The number of degenerate positions in one position weight matrix 
	(PSM).
-m:	The number of output motifs (default: 10).
-f:	The iteration time for each motif (default: 200).
-k:	The length of k-mers (default: 8).
-l:	The length of l-mer segments (default: 6).
-c:	The threshold for Hamming Distance used to connect nodes 
	(default: 1).
-r:	The threshold for deleting redundant motifs based on consensus
	(default: 1).
-p:	The boolean variable representing whether we consider positive
	strands only or both strands (default: 2).
-t:	The threshold to choose significant k-mers (default: 1.96).
-z:	The threshold to refine the preliminary motifs (default: 1.65).
-h:	Print this message (default: 0).

=========================================================================

Please feel free to contact liyangor@163.com, if you have any questions 
on the usage of this program.
