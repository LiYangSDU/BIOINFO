#!/bin/bash

./ProSampler -i input.fa -b input.bg -o output
